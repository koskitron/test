<div id="topbar" class="topbar navbar navbar-inverse navbar-fixed-top">

    <div class="navbar-inner">

      <div class="container-fluid">

        <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </a>

        <a class="brand" href="#top">Sales / Inventory System</a>

        <div class="nav-collapse">

          <ul class="nav pull-right">

            <li class="dropdown">
              
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                <!-- <img src="./images/profile.jpg" class="profile-pic" alt=""> -->
                <i class="icon-user icon-white"></i> Welcome, Admin <b class="caret"></b>
              </a>

              <ul class="dropdown-menu">
                <li><a href="#">Account</a></li>
                <li><a href="#">Settings</a></li>
                <li class="divider"></li>
                <li><a href="{{ URL::to_route('logout') }}">Logout</a></li>
              </ul>

            </li>

          </ul><!-- /.nav.pull-right -->

        </div><!-- /.nav-collapse -->

      </div><!-- /.container-fluid -->

    </div><!-- /.navbar-inner -->

</div><!-- /.navbar -->