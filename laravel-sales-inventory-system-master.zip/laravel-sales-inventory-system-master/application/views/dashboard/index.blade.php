@section('content')

    <div class="container-fluid">
        <div class="row-fluid">
            <div class="span12">
                <h1>Hello</h1>
            </div>
        </div>
    </div>

@endsection