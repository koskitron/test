<?php

Autoloader::map(array(
	'Datatables' => Bundle::path('datatables').'Datatables.php',
));