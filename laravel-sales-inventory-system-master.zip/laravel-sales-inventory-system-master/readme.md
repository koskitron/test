This is a Sales-Inventory system by Ted Mathew dela Cruz
as a study for integrating Laravel 3, Sass, DataTables.js, Backbone.js, and an extended Twitter Bootstrap dashboard template.

[hello@tedmdelacruz.com](mailto:hello@tedmdelacruz.com)
